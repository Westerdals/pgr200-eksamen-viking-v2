CREATE FUNCTION to_timestamp(double precision)
  RETURNS timestamp with time zone
IMMUTABLE
STRICT
COST 1
LANGUAGE SQL
AS $$
select ('epoch'::pg_catalog.timestamptz + $1 * '1 second'::pg_catalog.interval)
$$;

