CREATE FUNCTION integer_pl_date(integer, date)
  RETURNS date
IMMUTABLE
STRICT
COST 1
LANGUAGE SQL
AS $$
select $2 + $1
$$;

